import React from 'react'
import Card from './Card'

export default function Main() {
  return (
    <div className='container'>
        <Card/>
    </div>
  )
}
